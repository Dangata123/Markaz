$(document).ready(function() {
    // Smooth scrolling for navigation links
    $('a[href^="#"]').on('click', function(e) {
        e.preventDefault();
        
        var target = this.hash;
        var $target = $(target);
        
        $('html, body').animate({
            'scrollTop': $target.offset().top - 70
        }, 800, 'swing');
        
        // Update active nav item
        $('.course-nav .nav-link').removeClass('active');
        $(this).addClass('active');
    });
    
    // Mobile enroll button click handler
    $('.enroll-mobile-btn').on('click', function(e) {
        e.preventDefault();
        var enrollModal = new bootstrap.Modal(document.getElementById('enrollModal'));
        enrollModal.show();
    });
    
    // Enrollment button click handlers
    $('.enroll-btn').on('click', function() {
        alert('Thank you for enrolling in this course!');
    });
    
    $('.add-to-cart-btn').on('click', function() {
        alert('Course added to your cart!');
    });
    
    // Update active nav item on scroll
    $(window).on('scroll', function() {
        var scrollPos = $(document).scrollTop() + 100;
        
        $('.course-nav a').each(function() {
            var currLink = $(this);
            var refElement = $(currLink.attr("href"));
            
            if (refElement.position().top <= scrollPos && refElement.position().top + refElement.height() > scrollPos) {
                $('.course-nav .nav-link').removeClass('active');
                currLink.addClass('active');
            }
        });
    });
    
    // Curriculum accordion - track opened sections
    $('#curriculumAccordion').on('show.bs.collapse', function() {
        // You could track which sections users open for analytics
    });
});